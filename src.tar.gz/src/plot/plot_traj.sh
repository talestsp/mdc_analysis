PYTHONPATH=. ~/anaconda3/bin/python src/plot/plot_traj_server.py ordinary
